// Sticky header
window.addEventListener('scroll', () => {
    const header = document.querySelector('.navbar');
    if(window.scrollY > 50){
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }

    // Animate feature cards
    const featureCards = document.querySelectorAll('.feature-card');
    const triggerBottom = window.innerHeight * 0.85;

    featureCards.forEach(card => {
        const cardTop = card.getBoundingClientRect().top;
        if(cardTop < triggerBottom){
            card.classList.add('show');
        }
    });
});

// Mobile Menu Toggle
const menuBtn = document.getElementById('menuBtn');
const nav = document.querySelector('.nav');
menuBtn.addEventListener('click', () => {
    const expanded = menuBtn.getAttribute('aria-expanded') === 'true' || false;
    menuBtn.setAttribute('aria-expanded', !expanded);
    nav.classList.toggle('active');
});

// Hero letters animation
const heroTitle = document.querySelector('.hero-title');
if(heroTitle){
    heroTitle.innerHTML = heroTitle.textContent.replace(/\S/g, "<span class='letter'>$&</span>");
    const letters = document.querySelectorAll('.letter');
    letters.forEach((letter, i) => {
        letter.style.animation = `fadeLetter 0.5s ease forwards ${i * 0.05}s`;
    });
}
