function includeHTML() {
    const z = document.querySelectorAll('[w3-include-html]');
    z.forEach(el => {
      const file = el.getAttribute("w3-include-html");
      if(file){
        fetch(file)
        .then(response => {
          if(response.ok) return response.text();
          else return "Page not found.";
        })
        .then(data => {
          el.innerHTML = data;
          el.removeAttribute("w3-include-html");
          includeHTML(); // recursive for nested includes
        });
      }
    });
  }
  
  document.addEventListener("DOMContentLoaded", includeHTML);
  